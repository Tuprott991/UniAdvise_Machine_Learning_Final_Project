from fastapi import APIRouter, HTTPException

router = APIRouter()